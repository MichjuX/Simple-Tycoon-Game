package org.example.model;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

// Test jednostowy wygenerowany poprzez najechanie na Board, kliknięcie more actions, wybór create test, wybranie JUnit 5
class BoardTest {
    @Test
    void shouldRetrieveTheSameVelue(){
        Board board = new Board();
        board.set(0, 0, CellSymbol.X);
        assert board.get(0, 0) == CellSymbol.X;
    }
    @Test
    void shouldThrowExceptionWhenGettingElementOutOfRange(){
        Board board = new Board();
        board.get(999, 999);
        assertThrows(Board.OutOfRangeException.class, () -> board.set(999, 999, CellSymbol.X));
    }
    @Test
    void shouldThrowExceptionWhenSettingElementOutOfRange(){
        Board board = new Board();
        board.set(999, 999, CellSymbol.X);
        assertThrows(Board.OutOfRangeException.class, () -> board.set(999, 999, CellSymbol.X));
    }

}