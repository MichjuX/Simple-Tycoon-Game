package org.example.view.console;

public class BoardDrawer {
    public void drawBoard(){

    }
}
