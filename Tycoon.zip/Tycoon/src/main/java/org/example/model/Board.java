package org.example.model;

/*
x o -
- x -
- 0 -
 */
public class Board {
    private int SIZE = 3;
    private CellSymbol[][] board = new CellSymbol[SIZE][SIZE];

    public Board() {
        for (int row = 0; row < SIZE; row++) {
            for (int column = 0; column < SIZE; column++) {
                board[row][column] = CellSymbol.EMPTY;
            }
        }
    }
    public void set(int row, int column, CellSymbol cellSymbol){
        if(row > SIZE || column > SIZE){
            throw new OutOfRangeException();
        }
        board[row][column] = cellSymbol;
    }
    public CellSymbol get(int row, int column) {
        return board[row][column];
    }

    class OutOfRangeException extends RuntimeException {
    }
}

