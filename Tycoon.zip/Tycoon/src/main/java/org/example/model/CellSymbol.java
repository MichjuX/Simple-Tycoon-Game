package org.example.model;

public enum CellSymbol {
    X, O, EMPTY
}
