package org.example.model;

public class StateAnalyzer {
    public final Board board;

    public StateAnalyzer(Board board) {

        this.board = board;
    }

    public CellSymbol getWinningSymbol() {
        return CellSymbol.EMPTY;
    }
}
